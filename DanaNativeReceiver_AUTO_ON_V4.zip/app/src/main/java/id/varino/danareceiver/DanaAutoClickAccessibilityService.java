package id.varino.danareceiver;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityServiceInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.util.Log;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

/**
 * Optional user-enabled accessibility helper.
 * It watches only for this app's own DANA trigger notification, then uses
 * Android accessibility actions to click the visible "BUKA DANA" action.
 */
public class DanaAutoClickAccessibilityService extends AccessibilityService {
    public static final String TAG = "DanaAutoClick";
    private static final String BUTTON_TEXT = "BUKA DANA";
    private static final long RETRY_WINDOW_MS = 5000L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean armed = false;
    private boolean shadeRequested = false;
    private long armedAt = 0L;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        AccessibilityServiceInfo info = getServiceInfo();
        if (info != null) {
            info.eventTypes = AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED
                    | AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
                    | AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED;
            info.feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC;
            info.notificationTimeout = 100;
            info.flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
                    | AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS;
            info.packageNames = null; // We need System UI events while the helper is armed.
            setServiceInfo(info);
        }
        Log.i(TAG, "Accessibility helper aktif");
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null) return;

        CharSequence pkg = event.getPackageName();
        String packageName = pkg == null ? "" : pkg.toString();

        // Arm only when OUR notification is posted/updated with the DANA trigger text.
        if (AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED == event.getEventType()
                && getPackageName().equals(packageName)) {
            String text = eventText(event);
            if (text.contains("DANA Kaget terdeteksi") || text.contains(BUTTON_TEXT)) {
                armAndTryClick();
            }
        }

        if (armed) {
            tryClickButton();
        }
    }

    private String eventText(AccessibilityEvent event) {
        StringBuilder sb = new StringBuilder();
        for (CharSequence t : event.getText()) {
            if (t != null) sb.append(t).append(' ');
        }
        CharSequence desc = event.getContentDescription();
        if (desc != null) sb.append(desc);
        return sb.toString();
    }

    private void armAndTryClick() {
        armed = true;
        shadeRequested = false;
        armedAt = System.currentTimeMillis();
        handler.removeCallbacksAndMessages(null);
        handler.post(this::tryClickButton);
        handler.postDelayed(this::tryClickButton, 150);
        handler.postDelayed(this::tryClickButton, 350);
        handler.postDelayed(this::tryClickButton, 700);
        handler.postDelayed(this::tryClickButton, 1200);
        handler.postDelayed(this::tryClickButton, 2000);
        handler.postDelayed(this::tryClickButton, 3500);
        handler.postDelayed(this::tryClickButton, 5000);
    }

    private void tryClickButton() {
        if (!armed) return;
        if (System.currentTimeMillis() - armedAt > RETRY_WINDOW_MS) {
            armed = false;
            return;
        }

        AccessibilityNodeInfo root = getRootInActiveWindow();
        AccessibilityNodeInfo target = findButton(root);
        if (target != null) {
            boolean clicked = clickNode(target);
            target.recycle();
            if (clicked) {
                Log.i(TAG, "Tombol BUKA DANA diklik otomatis.");
                armed = false;
                handler.removeCallbacksAndMessages(null);
                return;
            }
        }
        if (root != null) root.recycle();

        // If the notification is not currently the active window, open the
        // notification shade. Subsequent System UI events are inspected above.
        if (!shadeRequested) {
            shadeRequested = true;
            performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS);
        }
    }

    private AccessibilityNodeInfo findButton(AccessibilityNodeInfo root) {
        if (root == null) return null;

        java.util.List<AccessibilityNodeInfo> nodes =
                root.findAccessibilityNodeInfosByText(BUTTON_TEXT);
        if (nodes != null) {
            for (AccessibilityNodeInfo node : nodes) {
                if (node != null && isUseful(node)) return node;
                if (node != null) node.recycle();
            }
        }

        // Some System UI versions expose the action label via contentDescription.
        return findByDescription(root, BUTTON_TEXT);
    }

    private AccessibilityNodeInfo findByDescription(AccessibilityNodeInfo node, String wanted) {
        if (node == null) return null;
        CharSequence d = node.getContentDescription();
        if (d != null && wanted.equalsIgnoreCase(d.toString().trim()) && isUseful(node)) {
            return node;
        }
        for (int i = 0; i < node.getChildCount(); i++) {
            AccessibilityNodeInfo child = node.getChild(i);
            AccessibilityNodeInfo found = findByDescription(child, wanted);
            if (found != null) return found;
            if (child != null) child.recycle();
        }
        return null;
    }

    private boolean isUseful(AccessibilityNodeInfo node) {
        CharSequence text = node.getText();
        CharSequence desc = node.getContentDescription();
        String value = text != null ? text.toString() : (desc != null ? desc.toString() : "");
        return BUTTON_TEXT.equalsIgnoreCase(value.trim()) || node.isClickable();
    }

    private boolean clickNode(AccessibilityNodeInfo node) {
        if (node.isClickable() && node.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
            return true;
        }
        AccessibilityNodeInfo parent = node.getParent();
        for (int i = 0; i < 5 && parent != null; i++) {
            if (parent.isClickable() && parent.performAction(AccessibilityNodeInfo.ACTION_CLICK)) {
                parent.recycle();
                return true;
            }
            AccessibilityNodeInfo next = parent.getParent();
            parent.recycle();
            parent = next;
        }
        if (parent != null) parent.recycle();
        return false;
    }

    @Override
    public void onInterrupt() {
        armed = false;
        Log.i(TAG, "Accessibility helper diinterupsi");
    }

    public static boolean isEnabled(android.content.Context context) {
        String enabled = Settings.Secure.getString(
                context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (TextUtils.isEmpty(enabled)) return false;
        String target = context.getPackageName() + "/" + DanaAutoClickAccessibilityService.class.getName();
        for (String item : enabled.split(":")) {
            if (target.equalsIgnoreCase(item)) return true;
        }
        return false;
    }
}
